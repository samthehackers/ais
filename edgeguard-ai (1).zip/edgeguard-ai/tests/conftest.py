import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'dataset'))
import numpy as np, pytest


def make_fixture_onnx(path, dets, nc=11, imgsz=640, n=30):
    """TEST FIXTURE ONLY. An ONNX graph that ignores its input and emits fixed YOLOv8-style output
    [1, 4+nc, n] containing `dets` = [(cls, conf, cx, cy, w, h)] in letterboxed pixel coordinates.
    It exercises loading/decoding/risk/alert/app plumbing; it says nothing about real detection accuracy."""
    import onnx
    from onnx import helper, TensorProto, numpy_helper
    T = np.zeros((1, 4 + nc, n), np.float32)
    for i, (c, cf, cx, cy, w, h) in enumerate(dets):
        T[0, :4, i] = (cx, cy, w, h); T[0, 4 + c, i] = cf
    nodes = [helper.make_node('ReduceSum', ['images'], ['s'], keepdims=0),
             helper.make_node('Mul', ['s', 'zero'], ['z']), helper.make_node('Add', ['T', 'z'], ['output0'])]
    g = helper.make_graph(nodes, 'fixture', [helper.make_tensor_value_info('images', TensorProto.FLOAT, [1, 3, imgsz, imgsz])],
                          [helper.make_tensor_value_info('output0', TensorProto.FLOAT, [1, 4 + nc, n])],
                          [numpy_helper.from_array(T, 'T'), numpy_helper.from_array(np.array(0.0, np.float32), 'zero')])
    m = helper.make_model(g, opset_imports=[helper.make_opsetid('', 13)]); m.ir_version = 8
    onnx.save(m, path)


def make_video(path, frames=240, w=640, h=480, fps=60):
    import cv2
    vw = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))
    rng = np.random.RandomState(0)
    for i in range(frames):
        vw.write((rng.rand(h, w, 3) * 255).astype(np.uint8))
    vw.release()


@pytest.fixture
def tmpproj(tmp_path):
    return tmp_path


import json, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeLLM:
    """Local OpenAI-compatible test server (stands in for OpenRouter / Ollama). status=500 simulates failure."""
    def __init__(self, reply=None, status=200, delay=0.0, bad_models=()):
        self.reply = reply or json.dumps({'toddler_present': True, 'hazards': ['knife'], 'danger': 'HIGH', 'explanation': 'child reaching for a knife'})
        self.status, self.delay, self.calls, self.last_auth, self.last_body = status, delay, 0, None, None
        self.bad_models, self.models_seen = set(bad_models), []
        outer = self
        class H(BaseHTTPRequestHandler):
            def log_message(s, *a): pass
            def do_GET(s): s.send_response(200); s.end_headers(); s.wfile.write(b'{}')
            def do_POST(s):
                body = json.loads(s.rfile.read(int(s.headers['Content-Length'])))
                outer.calls += 1; outer.last_auth = s.headers.get('Authorization'); outer.last_body = body
                time.sleep(outer.delay); outer.models_seen.append(body.get('model'))
                if body.get('model') in outer.bad_models: s.send_response(429); s.end_headers(); return
                if outer.status != 200: s.send_response(outer.status); s.end_headers(); return
                s.send_response(200); s.send_header('Content-Type', 'application/json'); s.end_headers()
                s.wfile.write(json.dumps({'choices': [{'message': {'content': outer.reply}}]}).encode())
        self.srv = ThreadingHTTPServer(('127.0.0.1', 0), H); self.port = self.srv.server_address[1]
        self.url = f'http://127.0.0.1:{self.port}/v1'
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self): self.srv.shutdown(); self.srv.server_close()


def free_port_url():
    import socket
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close()
    return f'http://127.0.0.1:{p}/v1'            # nothing listens here -> unreachable


@pytest.fixture
def llm():
    made = []
    def f(**kw):
        x = FakeLLM(**kw); made.append(x); return x
    yield f
    for x in made: x.close()
