import os, urllib.request
from alerts import AlertManager, EventStore
from risk_engine import RiskState

CFG = dict(audio=False, cooldown_high_s=30, cooldown_low_s=120, snapshot_dir='snaps', db_path='ev.db', telegram={'enabled': False})


def mk(tmp_path, **kw):
    cfg = {**CFG, **kw}
    return AlertManager(cfg, EventStore(str(tmp_path / 'ev.db')), str(tmp_path))


def S(level): return RiskState(level=level, hazard='knife', detection_conf=.9, risk_class_conf=.9)


def test_only_high_low_alert_and_cooldown(tmp_path):
    a = mk(tmp_path)
    assert a.handle(S('NO_RISK'), now=0) is None and a.handle(S('UNCERTAIN'), now=0) is None
    assert a.handle(S('HIGH'), now=100) is not None
    assert a.handle(S('HIGH'), now=110) is None                     # inside cooldown
    assert a.handle(S('HIGH'), now=131) is not None                 # after cooldown
    assert len(a.store.recent()) == 2


def test_recent_high_suppresses_low(tmp_path):
    a = mk(tmp_path); a.handle(S('HIGH'), now=100)
    assert a.handle(S('LOW'), now=105) is None and a.handle(S('LOW'), now=140) is not None


def test_snapshot_written(tmp_path):
    import numpy as np
    a = mk(tmp_path); eid = a.handle(S('HIGH'), np.zeros((50, 50, 3), np.uint8), now=1)
    ev = a.store.recent()[0]
    assert ev['id'] == eid and os.path.exists(tmp_path / ev['snapshot'])


def test_telegram_failure_never_raises_and_is_recorded(tmp_path, monkeypatch):
    monkeypatch.setenv('TG_T', 'x'); monkeypatch.setenv('TG_C', '1')
    def boom(*a, **k): raise OSError('offline')
    monkeypatch.setattr(urllib.request, 'urlopen', boom)
    a = mk(tmp_path, telegram={'enabled': True, 'token_env': 'TG_T', 'chat_id_env': 'TG_C', 'send_snapshot': False})
    assert a.handle(S('HIGH'), now=1) is not None                    # detection path unaffected
    import time; time.sleep(0.3)
    assert a.store.recent()[0]['telegram'].startswith('failed')


def test_telegram_without_credentials_is_disabled(tmp_path):
    a = mk(tmp_path, telegram={'enabled': True, 'token_env': 'NOPE1', 'chat_id_env': 'NOPE2'})
    assert a.tg.enabled is False
