import json, os
import cv2, numpy as np, pytest
import prepare_dataset as P

SCHEMA = os.path.join(os.path.dirname(__file__), '..', 'configs', 'classes.yaml')
REAL = '/mnt/user-data/uploads/project-2-at-2026-11-11-01-17-3d7c14a5.json'


def task(i, name, labels, cancelled=False, w=100, h=200, updated='2026-01-01'):
    res = [dict(type='rectanglelabels', original_width=w, original_height=h,
                value=dict(x=x, y=y, width=ww, height=hh, rotation=0, rectanglelabels=[l])) for l, x, y, ww, hh in labels]
    return dict(id=i, data=dict(image=f'/data/upload/2/{name}'), updated_at=updated,
                annotations=[dict(was_cancelled=cancelled, result=res, updated_at=updated)])


def test_coordinate_conversion_and_normalisation():
    recs, names = P.parse_export([task(1, 'aaaaaaaa-a.jpg', [('knive', 10, 20, 30, 40)])], SCHEMA)
    c, x, y, w, h = recs[0]['boxes'][0]
    assert names[c]['name'] == 'knife' and c == 9          # documented normalisation knive -> knife
    assert (round(x, 4), round(y, 4), round(w, 4), round(h, 4)) == (0.25, 0.4, 0.3, 0.4)


def test_status_and_original_name():
    ts = [task(1, 'deadbeef-x.jpg', [('adult male', 0, 0, 10, 10)]), task(2, 'deadbeef-y.jpg', [('adult male', 0, 0, 10, 10)], cancelled=True),
          task(3, 'cafebabe-z.jpg', [])]
    recs, _ = P.parse_export(ts, SCHEMA)
    assert [r['status'] for r in recs] == ['valid', 'cancelled', 'empty'] and recs[0]['orig'] == 'x.jpg'


def test_clipping_and_unknown_label_flagged():
    recs, _ = P.parse_export([task(1, 'a.jpg', [('adult male', 90, 90, 30, 30), ('martian', 0, 0, 5, 5)])], SCHEMA)
    assert 'box_clipped' in recs[0]['issues'] and any(i.startswith('unknown_label') for i in recs[0]['issues'])
    assert recs[0]['boxes'][0][3] <= 0.1 + 1e-9


def test_duplicates_and_conflicts():
    ts = [task(1, 'aaaaaaaa-p.jpg', [('adult male', 10, 10, 30, 30)]), task(2, 'bbbbbbbb-p.jpg', [('adult male', 10, 10, 30, 30)]),   # exact dup
          task(3, 'cccccccc-q.jpg', [('TODDLER NEAR KNIFE (HIGH RISK)', 10, 10, 30, 30)]),
          task(4, 'dddddddd-q.jpg', [('TODDLER NEAR KNIFE (NO RISK)', 10, 10, 30, 30)])]                                         # conflicting risk
    recs, names = P.parse_export(ts, SCHEMA)
    groups, _ = P.build_groups(recs)
    keep, dropped, conflicts = P.dedupe(recs, groups, 'quarantine')
    assert keep == [0] and dropped == 1 and conflicts == ['q.jpg']
    keep2, *_ = P.dedupe(recs, groups, 'keep-latest')
    assert len(keep2) == 2


def test_split_is_group_aware():
    ts = [task(i, f'{i:08x}-img{i // 3}.jpg', [('adult male', 10, 10, 30, 30)]) for i in range(60)]   # 20 filename groups of 3 copies
    recs, _ = P.parse_export(ts, SCHEMA)
    groups, _ = P.build_groups(recs)
    keep = list(range(60))
    sp = P.split_groups(recs, groups, keep)
    where = {}
    for s, ids in sp.items():
        for i in ids:
            assert where.setdefault(recs[i]['orig'], s) == s, 'duplicate leaked across splits'
    assert sum(len(v) for v in sp.values()) == 60


def test_end_to_end_build(tmp_path):
    imgs = tmp_path / 'imgs'; imgs.mkdir()
    ts = []
    rng = np.random.RandomState(1)
    for i in range(12):
        cv2.imwrite(str(imgs / f'img{i}.jpg'), (rng.rand(200, 100, 3) * 255).astype(np.uint8))
        ts.append(task(i, f'{i:08x}-img{i}.jpg', [('TODDLER NEAR KNIFE (HIGH RISK)' if i % 2 else 'adult male', 10, 10, 30, 30)]))
    ts.append(task(99, 'ffffffff-missing.jpg', [('adult male', 1, 1, 5, 5)]))              # image absent -> reported, excluded
    ex = tmp_path / 'e.json'; ex.write_text(json.dumps(ts))
    rc = P.main(['--export', str(ex), '--images', str(imgs), '--out', str(tmp_path / 'y'), '--report-dir', str(tmp_path / 'rep')])
    assert rc == 0
    a = json.load(open(tmp_path / 'rep' / 'audit.json'))
    assert '1 of 13' in a['missing_images']
    n_img = sum(len(os.listdir(tmp_path / 'y' / 'images' / s)) for s in ('train', 'val', 'test'))
    n_lbl = sum(len(os.listdir(tmp_path / 'y' / 'labels' / s)) for s in ('train', 'val', 'test'))
    assert n_img == n_lbl == 12 and os.path.exists(tmp_path / 'y' / 'data.yaml')


@pytest.mark.skipif(not os.path.exists(REAL), reason='real export not present')
def test_real_export_counts():
    recs, _ = P.parse_export(json.load(open(REAL)), SCHEMA)
    import collections
    assert len(recs) == 1930 and collections.Counter(r['status'] for r in recs) == {'valid': 1831, 'cancelled': 87, 'empty': 12}


def test_yolo_drop_folder_end_to_end(tmp_path):
    root = tmp_path / 'td'; (root / 'images').mkdir(parents=True); (root / 'labels').mkdir()
    rng = np.random.RandomState(3)
    (root / 'classes.txt').write_text('\n'.join(['TODDLER NEAR ELECTRIC IRON (HIGH RISK)', 'TODDLER NEAR ELECTRIC IRON (LOW RISK)', 'TODDLER NEAR ELECTRIC IRON (NO RISK)',
                                                  'TODDLER NEAR KNIFE (HIGH RISK)', 'TODDLER NEAR KNIFE (LOW RISK)', 'TODDLER NEAR KNIFE (NO RISK)',
                                                  'adult female', 'adult male', 'electric iron', 'knive', 'toddlers']))
    for i in range(12):
        cv2.imwrite(str(root / 'images' / f'{i:08x}-pic{i}.jpg'), (rng.rand(100, 80, 3) * 255).astype(np.uint8))
        if i < 10:   # Label Studio style: label name has the same prefix OR not; both must resolve
            nm = f'{i:08x}-pic{i}.txt' if i % 2 else f'pic{i}.txt'
            (root / 'labels' / nm).write_text('3 0.5 0.5 0.3 0.3\n' if i != 9 else '')
    (root / 'labels' / 'pic8.txt').write_text('3 0.5 0.5 0.3 0.3\nbad line\n9 2 2 2 2\n')
    rc = P.main(['--yolo-dir', str(root), '--out', str(tmp_path / 'y'), '--report-dir', str(tmp_path / 'rep')])
    a = json.load(open(tmp_path / 'rep' / 'audit.json'))
    assert rc == 0 and a['unlabelled_images_excluded'] == 2 and a['box_issues'].get('bad_label_line') == 2        # 2 images have no label file
    assert sum(len(os.listdir(tmp_path / 'y' / 'images' / s)) for s in ('train', 'val', 'test')) == 10
    assert open(tmp_path / 'rep' / 'unlabelled_images.txt').read().split() == ['0000000a-pic10.jpg', '0000000b-pic11.jpg']


def test_yolo_dir_rejects_mismatched_classes_txt(tmp_path):
    import pytest
    root = tmp_path / 'td'; (root / 'images').mkdir(parents=True); (root / 'labels').mkdir()
    (root / 'classes.txt').write_text('wrong\norder\n')
    with pytest.raises(SystemExit): P.parse_yolo_dir(str(root), SCHEMA)
