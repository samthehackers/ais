import os
from inference import load_classes
from risk_engine import Detection, RiskEngine, HIGH, LOW, UNCERTAIN, NO_RISK

CL = load_classes(os.path.join(os.path.dirname(__file__), '..', 'configs', 'classes.yaml'))
CFG = dict(high_conf=0.5, low_conf=0.4, uncertain_conf=0.2, window=8, high_hits=3, low_hits=4, uncertain_hits=3, clear_frames=4, proximity_hint=True)
B = (100, 100, 200, 200)
D = lambda c, conf, box=B: Detection(c, CL[c]['name'], conf, box)


def run(eng, frames):
    return [eng.update(f).level for f in frames]


def test_high_needs_persistence():
    e = RiskEngine(CL, CFG)
    lv = run(e, [[D(3, .9)]] * 3)
    assert lv[0] != HIGH and lv[1] != HIGH and lv[2] == HIGH          # single/double frames do not alarm


def test_single_spike_never_alarms_but_is_not_hidden():
    e = RiskEngine(CL, CFG)
    lv = run(e, [[D(3, .95)], [], [], []])
    assert HIGH not in lv


def test_low_when_low_class_persists():
    e = RiskEngine(CL, CFG)
    assert run(e, [[D(4, .8)]] * 4)[-1] == LOW


def test_no_detection_is_no_risk_and_confident_no_risk_class_is_no_risk():
    e = RiskEngine(CL, CFG)
    assert run(e, [[]] * 5)[-1] == NO_RISK
    e = RiskEngine(CL, CFG)
    assert run(e, [[D(5, .9)]] * 5)[-1] == NO_RISK


def test_uncertain_is_never_safe():
    e = RiskEngine(CL, CFG)
    lv = run(e, [[D(3, .3)]] * 4)                                      # HIGH class but below threshold
    assert lv[-1] == UNCERTAIN


def test_toddler_and_hazard_without_verdict_is_uncertain():
    e = RiskEngine(CL, CFG)
    lv = run(e, [[D(10, .8, (100, 100, 200, 300)), D(9, .7, (210, 250, 260, 300))]] * 4)
    assert lv[-1] == UNCERTAIN


def test_conflict_no_risk_vs_weak_high_is_uncertain():
    e = RiskEngine(CL, CFG)
    st = e.assess_frame([D(5, .9), D(3, .3)])
    assert st.frame_level == UNCERTAIN


def test_hysteresis_holds_high_until_window_ages_out_then_clears():
    e = RiskEngine(CL, CFG)                       # window=8, clear_frames=4
    run(e, [[D(3, .9)]] * 3)
    lv = run(e, [[]] * 10)
    assert lv[7] == HIGH                          # still HIGH: window holds the HIGH hits, then calm counter runs
    assert lv[-1] == NO_RISK                      # cleared only after the evidence aged out AND 4 calm frames


def test_proximity_hint_is_reported_not_decisive():
    e = RiskEngine(CL, CFG)
    st = e.assess_frame([D(10, .8, (100, 100, 200, 300)), D(8, .8, (210, 250, 260, 300))])
    assert st.proximity_hint is not None and st.proximity_hint > 0
    assert e.assess_frame([D(10, .8, (100, 100, 200, 300))]).proximity_hint is None


def test_runtime_threshold_change():
    e = RiskEngine(CL, CFG)
    assert e.assess_frame([D(3, .45)]).frame_level == UNCERTAIN
    e.update_config({**CFG, 'high_conf': 0.4})
    assert e.assess_frame([D(3, .45)]).frame_level == HIGH
