#!/usr/bin/env python3
"""Render research figures (PNG 300 DPI + PDF) from REAL outputs only. Missing inputs -> that figure is skipped and reported.

  python evaluation/plot_results.py --run runs/yolov8n --eval evaluation/results --out evaluation/plots
Inputs: <run>/results.csv (Ultralytics training log) and the files written by evaluate.py.
"""
import argparse, json, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

plt.rcParams.update({'font.size': 10, 'axes.titleweight': 'bold', 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.alpha': .3})
ap = argparse.ArgumentParser(); ap.add_argument('--run'); ap.add_argument('--eval', default='evaluation/results'); ap.add_argument('--out', default='evaluation/plots')
a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); done, skipped = [], []


def save(f, n):
    f.savefig(f'{a.out}/{n}.png', dpi=300, bbox_inches='tight'); f.savefig(f'{a.out}/{n}.pdf', bbox_inches='tight'); plt.close(f); done.append(n)


def short(s): return s.replace('TODDLER NEAR ', 'TN ').replace(' RISK', '')


rc = os.path.join(a.run or '', 'results.csv')
if a.run and os.path.exists(rc):
    df = pd.read_csv(rc); df.columns = [c.strip() for c in df.columns]; e = df['epoch']
    fig, ax = plt.subplots(1, 3, figsize=(14, 4))
    for i, k in enumerate(['box_loss', 'cls_loss', 'dfl_loss']):
        ax[i].plot(e, df[f'train/{k}'], label='Train'); ax[i].plot(e, df[f'val/{k}'], label='Validation'); ax[i].set(title=k, xlabel='Epoch', ylabel='Loss'); ax[i].legend()
    fig.suptitle('Training and validation loss'); save(fig, 'loss_curves')
    fig, ax = plt.subplots(figsize=(8, 5))
    for k, l in [('metrics/precision(B)', 'Precision'), ('metrics/recall(B)', 'Recall'), ('metrics/mAP50(B)', 'mAP@0.5'), ('metrics/mAP50-95(B)', 'mAP@0.5:0.95')]:
        if k in df: ax.plot(e, df[k], label=l)
    ax.set(xlabel='Epoch', ylabel='Score', title='Validation metrics per epoch'); ax.legend(); save(fig, 'validation_metrics_curves')
else: skipped.append('loss/metric curves (no results.csv)')

pc = f'{a.eval}/per_class_metrics.csv'
if os.path.exists(pc):
    t = pd.read_csv(pc).dropna(subset=['precision']); x = np.arange(len(t)); w = .27
    fig, ax = plt.subplots(figsize=(11, 5))
    for j, k in enumerate(['precision', 'recall', 'f1']): ax.bar(x + (j - 1) * w, t[k], w, label=k.capitalize())
    ax.set_xticks(x); ax.set_xticklabels([short(c) for c in t['cls']], rotation=40, ha='right'); ax.set(ylim=(0, 1), title='Per-class precision / recall / F1 (test set)'); ax.legend()
    for i, n in enumerate(t['n_gt']): ax.text(i, 1.01, f'n={n}', ha='center', fontsize=7)
    save(fig, 'per_class_prf1')
    fig, ax = plt.subplots(figsize=(11, 5)); ax.bar(x - .2, t['ap50'], .4, label='AP@0.5'); ax.bar(x + .2, t['ap50_95'], .4, label='AP@0.5:0.95')
    ax.set_xticks(x); ax.set_xticklabels([short(c) for c in t['cls']], rotation=40, ha='right'); ax.set(title='Per-class average precision (test set)'); ax.legend(); save(fig, 'per_class_ap')
else: skipped.append('per-class charts (no per_class_metrics.csv; run evaluate.py)')

cmf = f'{a.eval}/confusion_matrix.csv'
if os.path.exists(cmf):
    m = pd.read_csv(cmf, index_col=0); v = m.values.astype(float); n = v / np.maximum(v.sum(0, keepdims=True), 1)
    fig, ax = plt.subplots(figsize=(10, 9)); im = ax.imshow(n, cmap='Blues'); L = [short(c) for c in m.columns]
    ax.set_xticks(range(len(L))); ax.set_yticks(range(len(L))); ax.set_xticklabels(L, rotation=60, ha='right', fontsize=7); ax.set_yticklabels(L, fontsize=7); ax.grid(False)
    for i in range(len(L)):
        for j in range(len(L)):
            if v[i, j]: ax.text(j, i, int(v[i, j]), ha='center', va='center', fontsize=6, color='white' if n[i, j] > .5 else 'black')
    ax.set(xlabel='True', ylabel='Predicted', title='Confusion matrix (test set, colour = column-normalised)'); fig.colorbar(im, fraction=.04); save(fig, 'confusion_matrix')
else: skipped.append('confusion matrix (no confusion_matrix.csv)')

pr = f'{a.eval}/pr_curves.csv'
if os.path.exists(pr):
    d = pd.read_csv(pr); fig, ax = plt.subplots(figsize=(8, 6))
    for c, g in d.groupby('class'): ax.plot(g['recall'], g['precision'], label=short(c))
    ax.set(xlabel='Recall', ylabel='Precision', title='Precision-recall curves @ IoU 0.5 (test set)', xlim=(0, 1), ylim=(0, 1.02)); ax.legend(fontsize=6); save(fig, 'pr_curves')
else: skipped.append('PR curves')

for fn, nm in (('false_positives.csv', 'false_positive_analysis'), ('false_negatives.csv', 'false_negative_analysis')):
    p = f'{a.eval}/{fn}'
    if os.path.exists(p):
        d = pd.read_csv(p)
        if len(d):
            col = 'predicted' if 'positives' in fn else 'true'
            c = d.groupby([col, 'type']).size().unstack(fill_value=0)
            c.index = [short(i) for i in c.index]; ax = c.plot.barh(stacked=True, figsize=(9, 5)); ax.set_title(nm.replace('_', ' ').title() + ' (test set)'); ax.set_xlabel('Count')
            save(ax.figure, nm)

json.dump(dict(rendered=done, skipped=skipped), open(f'{a.out}/plot_manifest.json', 'w'), indent=2); print(f'rendered {done}\nskipped {skipped}')
