#!/usr/bin/env bash
# Run EDGEGUARD AI in the foreground (development / manual use).
set -euo pipefail
cd "$(dirname "$0")"
[ -f .venv/bin/activate ] && . .venv/bin/activate
[ -f edgeguard.env ] && set -a && . ./edgeguard.env && set +a
exec python3 app.py --config "${EDGEGUARD_CONFIG:-config.yaml}" "$@"
