"""Optional multimodal-LLM second opinion. ADVISORY ONLY.

The detector + risk engine work completely on their own, online or offline. This module can add a plain-language
description to alert events and dropped images:
  online  : OpenRouter (OpenAI-compatible)       key from env OPENROUTER_API_KEY
  offline : any local OpenAI-compatible server (Ollama, llama.cpp server, LM Studio) on the Pi / LAN
Safety rules: it runs in a background queue (never delays detection), it can never lower or clear a risk level or
suppress an alert, failures are recorded and ignored, and nothing is sent anywhere unless a key (online) or a model
name (offline) is configured. Sending images to OpenRouter means they leave the device: that is opt-in by setting the key.
"""
import base64, json, logging, os, queue, re, socket, threading, time, urllib.request
from urllib.parse import urlparse
import cv2

log = logging.getLogger('edgeguard.mllm')
PROMPT = ("You are a visual safety assistant for a home child-safety monitor. Look at the image. Answer ONLY with JSON: "
          '{"toddler_present": true|false, "hazards": ["knife"|"electric iron"|other dangerous objects seen], '
          '"danger": "HIGH"|"LOW"|"NONE"|"UNSURE", "explanation": "one or two short sentences"}. '
          "HIGH = a young child is close to or touching a knife or hot/plugged-in iron. LOW = a child and a hazard are in "
          "the same area but not clearly close. NONE = no child-hazard danger visible. Use UNSURE if you cannot tell. "
          "Do not guess; describe only what is visible.")


def encode_image(bgr, max_px=768, quality=80):
    h, w = bgr.shape[:2]; s = min(1.0, max_px / max(h, w))
    if s < 1.0:
        bgr = cv2.resize(bgr, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode('.jpg', bgr, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok: raise ValueError('cannot encode image')
    return base64.b64encode(buf.tobytes()).decode()


def parse_reply(text):
    """Tolerant parse of the model's reply. Never raises; unparseable output becomes danger=UNSURE."""
    t = (text or '').strip()
    t = re.sub(r'^```(?:json)?|```$', '', t, flags=re.M).strip()
    m = re.search(r'\{.*\}', t, re.S)
    try:
        j = json.loads(m.group(0)) if m else {}
    except ValueError:
        j = {}
    danger = str(j.get('danger', 'UNSURE')).upper()
    if danger not in ('HIGH', 'LOW', 'NONE', 'UNSURE'): danger = 'UNSURE'
    return dict(danger=danger, toddler_present=j.get('toddler_present'), hazards=j.get('hazards') if isinstance(j.get('hazards'), list) else [],
                summary=str(j.get('explanation') or t[:300])[:400])


class Backend:
    def __init__(self, name, cfg, needs_key):
        self.name, self.cfg = name, cfg
        self.base = cfg.get('base_url', '').rstrip('/')
        self.models = [m for m in (cfg.get('models') or [cfg.get('model')]) if m]          # tried in order (fallback chain)
        self.model = self.models[0] if self.models else ''
        self.data_collection = cfg.get('data_collection')                                   # OpenRouter: "allow" | "deny"
        self.cooldown_s = float(cfg.get('model_cooldown_s', 300)); self._bad = {}           # model -> retry-after timestamp
        self.last_model = None
        self.key = os.environ.get(cfg.get('api_key_env', ''), '') if needs_key else ''
        self.needs_key = needs_key; self.timeout = float(cfg.get('timeout_s', 60))
        self._probe = (0.0, False)

    @property
    def configured(self):
        return bool(self.base and self.model and (self.key or not self.needs_key))

    def reachable(self, ttl=30):
        t, v = self._probe
        if time.time() - t < ttl: return v
        try:
            u = urlparse(self.base); socket.create_connection((u.hostname, u.port or (443 if u.scheme == 'https' else 80)), 2).close(); v = True
        except OSError:
            v = False
        self._probe = (time.time(), v); return v

    def _post(self, model, b64, context):
        body = {'model': model, 'temperature': 0, 'max_tokens': 300,
                'messages': [{'role': 'user', 'content': [{'type': 'text', 'text': PROMPT + (f'\nDetector hint (may be wrong): {context}' if context else '')},
                                                           {'type': 'image_url', 'image_url': {'url': f'data:image/jpeg;base64,{b64}'}}]}]}
        if self.data_collection in ('allow', 'deny'):
            body['provider'] = {'data_collection': self.data_collection}
        h = {'Content-Type': 'application/json', 'X-Title': 'EDGEGUARD AI'}
        if self.key: h['Authorization'] = f'Bearer {self.key}'
        req = urllib.request.Request(self.base + '/chat/completions', json.dumps(body).encode(), h)
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            data = json.loads(r.read().decode())
        return parse_reply(data['choices'][0]['message']['content'])

    def query(self, b64, context=''):
        """Try each model in order; a model that errors (rate limit, retired, no endpoint) is skipped for `cooldown_s`."""
        errs = []; now = time.time()
        order = [m for m in self.models if self._bad.get(m, 0) <= now] or list(self.models)   # all cooling down -> try anyway
        for m in order:
            try:
                r = self._post(m, b64, context); self.last_model = m; r['model_used'] = m; return r
            except Exception as e:                                         # noqa: BLE001
                code = getattr(e, 'code', None)
                self._bad[m] = now + self.cooldown_s; errs.append(f'{m}: {code or type(e).__name__}')
        raise RuntimeError('all models failed: ' + '; '.join(errs))


class MLLM:
    def __init__(self, cfg):
        self.cfg = cfg or {}; self.mode = self.cfg.get('mode', 'auto')
        self.online = Backend('online', {**self.cfg.get('online', {}), 'timeout_s': self.cfg.get('online', {}).get('timeout_s', 60)}, True)
        self.offline = Backend('offline', self.cfg.get('offline', {}), False)
        self.max_px = int(self.cfg.get('max_image_px', 768)); self.min_interval = float(self.cfg.get('min_interval_s', 10))
        self.q = queue.Queue(maxsize=8); self.stop_evt = threading.Event(); self.t = threading.Thread(target=self._run, daemon=True, name='mllm')
        self.last = None; self.last_event_ts = 0.0; self.done = 0; self.failed = 0

    def start(self):
        if self.mode != 'off': self.t.start()
        return self

    def stop(self):
        self.stop_evt.set()
        if self.t.is_alive(): self.t.join(timeout=2)

    def route(self):
        """Pick the backend for the next job; None means detector-only operation."""
        if self.mode == 'off': return None
        cands = {'online': [self.online], 'offline': [self.offline], 'auto': [self.online, self.offline]}.get(self.mode, [])
        for b in cands:
            if b.configured and b.reachable(): return b
        return None

    def enabled_for(self, kind): return self.mode != 'off' and kind in self.cfg.get('use_for', ['events', 'inbox'])

    def submit(self, bgr, context, callback, kind='event'):
        """Queue a job; returns False (and does nothing) if disabled/rate-limited/full. Never blocks."""
        if not self.enabled_for('events' if kind == 'event' else 'inbox'): return False
        if kind == 'event':
            if time.time() - self.last_event_ts < self.min_interval: return False
            self.last_event_ts = time.time()
        try:
            self.q.put_nowait((encode_image(bgr, self.max_px), context, callback)); return True
        except queue.Full:
            log.warning('mllm queue full; job dropped'); return False

    def _run(self):
        while not self.stop_evt.is_set():
            try: b64, ctx, cb = self.q.get(timeout=0.5)
            except queue.Empty: continue
            res = self._call(b64, ctx)
            self.last = res; self.done += 1; self.failed += (not res['ok'])
            try: cb(res)
            except Exception as e: log.error('mllm callback failed: %s', e)   # noqa: BLE001

    def _call(self, b64, ctx):
        tried = []
        order = {'online': [self.online], 'offline': [self.offline], 'auto': [self.online, self.offline]}.get(self.mode, [])
        for b in order:
            if not (b.configured and b.reachable(ttl=5)): continue
            t0 = time.time()
            try:
                r = b.query(b64, ctx)
                return dict(ok=True, backend=b.name, model=r.pop('model_used', b.model), latency_s=round(time.time() - t0, 1), advisory=True, **r)
            except Exception as e:                                     # noqa: BLE001 - fall through to next backend
                tried.append(f'{b.name}: {e if isinstance(e, RuntimeError) else type(e).__name__}'); b._probe = (0.0, False)
        return dict(ok=False, backend=None, error='; '.join(tried) or 'no MLLM backend available (detector result stands)', advisory=True)

    def status(self):
        r = self.route()
        return dict(mode=self.mode, active_backend=r.name if r else None, queue=self.q.qsize(), completed=self.done, failed=self.failed,
                    online=dict(configured=self.online.configured, models=self.online.models, key_set=bool(self.online.key), data_collection=self.online.data_collection, last_model=self.online.last_model),
                    offline=dict(configured=self.offline.configured, model=self.offline.model, models=self.offline.models, base_url=self.offline.base),
                    last=self.last, note='advisory only: never lowers a risk level or suppresses an alert')
