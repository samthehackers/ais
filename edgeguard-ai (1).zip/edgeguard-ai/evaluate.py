#!/usr/bin/env python3
"""Evaluate a model on the held-out TEST split using the same ONNX path the Pi runs.

  python evaluate.py --model models/best.onnx --data dataset/yolo/data.yaml --split test --out evaluation/results
Outputs (all computed from real predictions): metrics.json, per_class_metrics.csv, confusion_matrix.csv,
false_positives.csv, false_negatives.csv, pr_curves.csv. mAP@50 and mAP@50:95 are computed here with the
standard all-point interpolated AP (COCO-style IoU thresholds 0.50:0.05:0.95) so ONNX/INT8/FP32 are comparable.
Use evaluation/plot_results.py to render figures from these files.
"""
import argparse, csv, glob, json, os
import numpy as np
import yaml
import cv2
from inference import Detector, load_classes


def iou_xyxy(a, b):
    iw = max(0, min(a[2], b[2]) - max(a[0], b[0])); ih = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    i = iw * ih; u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - i
    return i / u if u > 0 else 0.0


def load_gt(lbl, w, h):
    out = []
    if os.path.exists(lbl):
        for l in open(lbl).read().split('\n'):
            p = l.split()
            if len(p) == 5:
                c, x, y, bw, bh = int(p[0]), *map(float, p[1:])
                out.append((c, (x - bw / 2) * w, (y - bh / 2) * h, (x + bw / 2) * w, (y + bh / 2) * h))
    return out


def ap_from_pr(rec, prec):
    mrec = np.concatenate([[0], rec, [1]]); mpre = np.concatenate([[1], prec, [0]])
    mpre = np.flip(np.maximum.accumulate(np.flip(mpre)))
    x = np.linspace(0, 1, 101)
    return float(np.trapz(np.interp(x, mrec, mpre), x))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True); ap.add_argument('--data', required=True); ap.add_argument('--split', default='test')
    ap.add_argument('--out', default='evaluation/results'); ap.add_argument('--conf', type=float, default=0.25, help='operating threshold for P/R/F1/confusion')
    ap.add_argument('--classes', default='configs/classes.yaml'); ap.add_argument('--imgsz', type=int, default=640)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    d = yaml.safe_load(open(a.data)); root = d['path']
    img_dir = os.path.join(root, d[a.split]) if not str(d[a.split]).endswith('.txt') else None
    files = sorted(glob.glob(os.path.join(img_dir, '*'))) if img_dir else [l.strip() for l in open(os.path.join(root, d[a.split])) if l.strip()]
    files = [f for f in files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    if not files: raise SystemExit(f'no images found for split {a.split}')
    det = Detector(dict(path=os.path.abspath(a.model), classes_file=os.path.abspath(a.classes), imgsz=a.imgsz, conf_floor=0.001, nms_iou=0.6, threads=4), base_dir='/')
    if not det.ready: raise SystemExit(det.error)
    nc = det.nc; names = [det.classes[i]['name'] for i in range(nc)]
    iou_ts = np.arange(0.5, 0.96, 0.05)
    recs = {c: [] for c in range(nc)}       # per class: list of (conf, [tp@each iou])
    npos = np.zeros(nc, int); cm = np.zeros((nc + 1, nc + 1), int)   # rows predicted, cols true; last = background
    fps, fns = [], []
    for f in files:
        im = cv2.imread(f)
        if im is None: continue
        H, W = im.shape[:2]
        lbl = os.path.join(os.path.dirname(f).replace('images', 'labels'), os.path.splitext(os.path.basename(f))[0] + '.txt')
        gt = load_gt(lbl, W, H)
        preds = [(p.cls_id, p.conf, p.box) for p in det.predict(im)]
        for g in gt: npos[g[0]] += 1
        # AP matching per class and IoU threshold
        for c in range(nc):
            pc = sorted([p for p in preds if p[0] == c], key=lambda p: -p[1]); gc = [g for g in gt if g[0] == c]
            tps = {p[1]: np.zeros(len(iou_ts), bool) for p in pc}
            row = []
            for ti, t in enumerate(iou_ts):
                used = set(); flags = []
                for p in pc:
                    best, bj = 0, -1
                    for j, g in enumerate(gc):
                        if j in used: continue
                        v = iou_xyxy(p[2], g[1:])
                        if v > best: best, bj = v, j
                    if best >= t: used.add(bj); flags.append(True)
                    else: flags.append(False)
                row.append(flags)
            for k, p in enumerate(pc):
                recs[c].append((p[1], np.array([row[ti][k] for ti in range(len(iou_ts))])))
        # operating-point confusion matrix + FP/FN lists at IoU 0.5
        op = [p for p in preds if p[1] >= a.conf]; used = set()
        for p in op:
            best, bj = 0.0, -1
            for j, g in enumerate(gt):
                if j in used: continue
                v = iou_xyxy(p[2], g[1:])
                if v > best: best, bj = v, j
            if best >= 0.5:
                used.add(bj); cm[p[0], gt[bj][0]] += 1
                if p[0] != gt[bj][0]: fps.append((os.path.basename(f), 'wrong_class', names[p[0]], names[gt[bj][0]], round(p[1], 3)))
            else:
                cm[p[0], nc] += 1; fps.append((os.path.basename(f), 'spurious', names[p[0]], '', round(p[1], 3)))
        for j, g in enumerate(gt):
            if j not in used:
                cm[nc, g[0]] += 1; fns.append((os.path.basename(f), 'missed', '', names[g[0]], 0))
    per = []; aps50 = []; aps = []
    pr_rows = []
    for c in range(nc):
        r = sorted(recs[c], key=lambda x: -x[0])
        if npos[c] == 0:
            per.append(dict(cls=names[c], n_gt=0, precision=None, recall=None, f1=None, ap50=None, ap50_95=None)); continue
        tp = np.array([x[1] for x in r]) if r else np.zeros((0, len(iou_ts)), bool)
        apl = []
        for ti in range(len(iou_ts)):
            t = tp[:, ti] if len(tp) else np.zeros(0, bool)
            ctp = np.cumsum(t); cfp = np.cumsum(~t)
            rec = ctp / npos[c] if len(t) else np.zeros(0); prec = ctp / np.maximum(ctp + cfp, 1) if len(t) else np.zeros(0)
            apl.append(ap_from_pr(rec, prec) if len(t) else 0.0)
            if ti == 0 and len(t):
                pr_rows += [(names[c], float(x), float(y)) for x, y in zip(rec[::max(1, len(rec) // 100)], prec[::max(1, len(rec) // 100)])]
        TP = cm[c, c]; FP = cm[c, :].sum() - TP; FN = cm[:, c].sum() - TP
        P = TP / (TP + FP) if TP + FP else 0.0; R = TP / (TP + FN) if TP + FN else 0.0
        per.append(dict(cls=names[c], n_gt=int(npos[c]), precision=round(P, 4), recall=round(R, 4), f1=round(2 * P * R / (P + R), 4) if P + R else 0.0,
                        ap50=round(apl[0], 4), ap50_95=round(float(np.mean(apl)), 4)))
        aps50.append(apl[0]); aps.append(float(np.mean(apl)))
    metrics = dict(model=os.path.abspath(a.model), split=a.split, images=len(files), operating_conf=a.conf,
                   mAP50=round(float(np.mean(aps50)), 4) if aps50 else None, mAP50_95=round(float(np.mean(aps)), 4) if aps else None,
                   classes_without_test_examples=[names[c] for c in range(nc) if npos[c] == 0],
                   low_support_classes_lt10=[names[c] for c in range(nc) if 0 < npos[c] < 10])
    json.dump(metrics, open(f'{a.out}/metrics.json', 'w'), indent=2)
    with open(f'{a.out}/per_class_metrics.csv', 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(per[0].keys())); w.writeheader(); w.writerows(per)
    with open(f'{a.out}/confusion_matrix.csv', 'w', newline='') as fh:
        w = csv.writer(fh); w.writerow(['pred\\true'] + names + ['background'])
        for i, row in enumerate(cm): w.writerow((names + ['background'])[i:i + 1] + list(map(int, row)))
    for fn, hdr, rows in (('false_positives.csv', ['image', 'type', 'predicted', 'true', 'conf'], fps),
                          ('false_negatives.csv', ['image', 'type', 'predicted', 'true', 'conf'], fns),
                          ('pr_curves.csv', ['class', 'recall', 'precision'], pr_rows)):
        with open(f'{a.out}/{fn}', 'w', newline='') as fh:
            w = csv.writer(fh); w.writerow(hdr); w.writerows(rows)
    print(json.dumps(metrics, indent=2))


if __name__ == '__main__':
    main()
