"""Risk intelligence engine.

Architecture decision (approach A): the detector directly outputs the six toddler-near-hazard risk
classes, because the dataset labels them as scene-level classes and contains almost no separate
toddler/hazard boxes (see dataset/audit_report.md). This engine turns noisy per-frame detections into a
stable, conservative state:

    HIGH / LOW / UNCERTAIN / NO_RISK

Three quantities are kept separate and reported: detection confidence, risk-class confidence, and an
OPTIONAL image-plane proximity hint. The hint is NOT a physical distance (an uncalibrated single camera
cannot measure one) and never changes the state by itself.

Safety rule: an uncertain observation is never reported as safe. NO_RISK only means that the model saw
no relevant danger above the configured confidence floors.
"""
from collections import deque
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

HIGH, LOW, UNCERTAIN, NO_RISK = 'HIGH', 'LOW', 'UNCERTAIN', 'NO_RISK'
SEVERITY = {NO_RISK: 0, UNCERTAIN: 1, LOW: 2, HIGH: 3}


@dataclass
class Detection:
    cls_id: int
    name: str
    conf: float
    box: Tuple[float, float, float, float]   # x1, y1, x2, y2 in pixels


@dataclass
class RiskState:
    level: str = NO_RISK
    frame_level: str = NO_RISK
    hazard: Optional[str] = None
    detection_conf: float = 0.0           # best detector confidence behind the current frame level
    risk_class_conf: float = 0.0          # confidence of the risk-labelled class
    proximity_hint: Optional[float] = None
    reasons: List[str] = field(default_factory=list)

    def to_dict(self):
        return dict(level=self.level, frame_level=self.frame_level, hazard=self.hazard,
                    detection_conf=round(self.detection_conf, 3), risk_class_conf=round(self.risk_class_conf, 3),
                    proximity_hint=None if self.proximity_hint is None else round(self.proximity_hint, 3),
                    reasons=self.reasons)


def _iou(a, b):
    iw = max(0.0, min(a[2], b[2]) - max(a[0], b[0])); ih = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    i = iw * ih
    u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - i
    return i / u if u > 0 else 0.0


def proximity_hint(toddler_box, hazard_box):
    """Edge-to-edge gap between boxes divided by the toddler box height (0 = touching/overlapping).
    Image-plane only; depends on camera angle and perspective. Reported as a hint, never as metres."""
    dx = max(0.0, max(toddler_box[0], hazard_box[0]) - min(toddler_box[2], hazard_box[2]))
    dy = max(0.0, max(toddler_box[1], hazard_box[1]) - min(toddler_box[3], hazard_box[3]))
    h = max(toddler_box[3] - toddler_box[1], 1e-6)
    return ((dx * dx + dy * dy) ** 0.5) / h


class RiskEngine:
    def __init__(self, classes: dict, cfg: dict):
        self.classes, self.cfg = classes, cfg
        self.hist = deque(maxlen=int(cfg['window']))
        self.state = NO_RISK
        self.calm = 0

    def update_config(self, cfg):
        self.cfg = cfg
        self.hist = deque(self.hist, maxlen=int(cfg['window']))

    # ---- per-frame ---------------------------------------------------------------------------------
    def assess_frame(self, dets: List[Detection]) -> RiskState:
        c = self.cfg
        sig = []   # (level, det)
        reasons = []
        risk_dets = [d for d in dets if self.classes[d.cls_id]['kind'] == 'risk']
        for d in risk_dets:
            lvl = self.classes[d.cls_id]['level']
            thr = {'HIGH': c['high_conf'], 'LOW': c['low_conf'], 'NO': c['low_conf']}[lvl]
            if d.conf >= thr:
                sig.append(({'HIGH': HIGH, 'LOW': LOW, 'NO': NO_RISK}[lvl], d))
            elif d.conf >= c['uncertain_conf']:
                sig.append((UNCERTAIN, d))
                reasons.append(f"{d.name} below threshold ({d.conf:.2f})")
        # Self-contradiction: confident NO-RISK overlapping a weaker HIGH/LOW on the same hazard -> UNCERTAIN
        extra = []
        for lvl, d in sig:
            if lvl != NO_RISK:
                continue
            for lv2, d2 in sig:
                if lv2 == UNCERTAIN and self.classes[d2.cls_id]['level'] in ('HIGH', 'LOW') \
                        and self.classes[d2.cls_id]['hazard'] == self.classes[d.cls_id]['hazard'] \
                        and _iou(d.box, d2.box) > 0.5:
                    extra.append((UNCERTAIN, d2)); reasons.append('model disagrees with itself on one object')
        sig.extend(extra)
        # Hazard / toddler seen without any risk verdict -> UNCERTAIN, not safe
        toddlers = [d for d in dets if self.classes[d.cls_id].get('role') == 'toddler' and d.conf >= c['uncertain_conf']]
        hazards = [d for d in dets if self.classes[d.cls_id]['kind'] == 'hazard' and d.conf >= c['uncertain_conf']]
        if toddlers and hazards and not any(l in (HIGH, LOW, NO_RISK) for l, _ in sig):
            sig.append((UNCERTAIN, max(hazards, key=lambda d: d.conf)))
            reasons.append('toddler and hazard visible but no risk verdict')
        st = RiskState()
        if sig:
            lvl, d = max(sig, key=lambda s: (SEVERITY[s[0]], s[1].conf))
            st.frame_level, st.detection_conf = lvl, d.conf
            if self.classes[d.cls_id]['kind'] == 'risk':
                st.risk_class_conf = d.conf
            st.hazard = self.classes[d.cls_id].get('hazard')
        st.reasons = reasons
        if c.get('proximity_hint') and toddlers and hazards:
            st.proximity_hint = min(proximity_hint(t.box, h.box) for t in toddlers for h in hazards)
        return st

    # ---- temporal smoothing ------------------------------------------------------------------------
    def update(self, dets: List[Detection]) -> RiskState:
        c = self.cfg
        fs = self.assess_frame(dets)
        self.hist.append(fs.frame_level)
        n_high = sum(1 for x in self.hist if x == HIGH)
        n_hl = sum(1 for x in self.hist if x in (HIGH, LOW))
        n_unc = sum(1 for x in self.hist if x == UNCERTAIN)
        if n_high >= c['high_hits']:
            target = HIGH
        elif n_hl >= c['low_hits']:
            target = LOW
        elif n_unc + n_hl >= c['uncertain_hits']:
            target = UNCERTAIN   # persistent doubt (including short HIGH/LOW bursts) is surfaced, not hidden
        else:
            target = NO_RISK
        if SEVERITY[target] >= SEVERITY[self.state]:
            self.state, self.calm = target, 0
        else:
            self.calm += 1
            if self.calm >= c['clear_frames']:
                self.state, self.calm = target, 0
        fs.level = self.state
        return fs

    def reset(self):
        self.hist.clear(); self.state = NO_RISK; self.calm = 0
