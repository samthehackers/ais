"""ONNX Runtime detector for YOLOv8/YOLO11-style exports (output [1, 4+nc, N]). CPU only, no torch needed."""
import json, os, threading, time
import numpy as np
import yaml
from risk_engine import Detection


def load_classes(path):
    with open(path) as f:
        y = yaml.safe_load(f)
    cl = {int(k): v for k, v in y['classes'].items()}
    for k, v in cl.items():          # fail loudly on schema mistakes (e.g. an unquoted YAML NO becomes False)
        if v.get('kind') not in ('risk', 'person', 'hazard'):
            raise ValueError(f'class {k}: invalid kind {v.get("kind")!r}')
        if v['kind'] == 'risk' and v.get('level') not in ('HIGH', 'LOW', 'NO'):
            raise ValueError(f'class {k}: invalid risk level {v.get("level")!r} (quote "NO" in YAML)')
    if sorted(cl) != list(range(len(cl))):
        raise ValueError('class ids must be contiguous from 0')
    return cl


def letterbox(img, size=640, color=114):
    import cv2
    h, w = img.shape[:2]
    r = min(size / h, size / w)
    nh, nw = int(round(h * r)), int(round(w * r))
    if (nh, nw) != (h, w):
        img = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top, left = (size - nh) // 2, (size - nw) // 2
    out = np.full((size, size, 3), color, dtype=np.uint8)
    out[top:top + nh, left:left + nw] = img
    return out, r, left, top


def nms(boxes, scores, iou_thr):
    if len(boxes) == 0:
        return []
    x1, y1, x2, y2 = boxes.T
    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]
    keep = []
    while order.size:
        i = order[0]; keep.append(int(i))
        xx1, yy1 = np.maximum(x1[i], x1[order[1:]]), np.maximum(y1[i], y1[order[1:]])
        xx2, yy2 = np.minimum(x2[i], x2[order[1:]]), np.minimum(y2[i], y2[order[1:]])
        inter = np.maximum(0, xx2 - xx1) * np.maximum(0, yy2 - yy1)
        iou = inter / (areas[i] + areas[order[1:]] - inter + 1e-9)
        order = order[1:][iou <= iou_thr]
    return keep


def decode(output, nc, ratio, left, top, orig_hw, conf_floor=0.15, iou_thr=0.5):
    """output: raw model output. Returns list of (cls, conf, x1, y1, x2, y2) in original-image pixels."""
    p = np.asarray(output)
    p = p[0] if p.ndim == 3 else p
    if p.shape[0] == 4 + nc:
        p = p.T                                    # -> [N, 4+nc]
    elif p.shape[1] != 4 + nc:
        raise ValueError(f'unexpected output shape {p.shape} for nc={nc}')
    scores_all = p[:, 4:]
    cls = scores_all.argmax(1); conf = scores_all.max(1)
    m = conf >= conf_floor
    p, cls, conf = p[m], cls[m], conf[m]
    if not len(p):
        return []
    cx, cy, w, h = p[:, 0], p[:, 1], p[:, 2], p[:, 3]
    b = np.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], 1)
    b[:, [0, 2]] = (b[:, [0, 2]] - left) / ratio
    b[:, [1, 3]] = (b[:, [1, 3]] - top) / ratio
    H, W = orig_hw
    b[:, [0, 2]] = b[:, [0, 2]].clip(0, W); b[:, [1, 3]] = b[:, [1, 3]].clip(0, H)
    res = []
    for c in np.unique(cls):                       # per-class NMS
        idx = np.where(cls == c)[0]
        for k in nms(b[idx], conf[idx], iou_thr):
            j = idx[k]; res.append((int(c), float(conf[j]), *map(float, b[j])))
    return sorted(res, key=lambda r: -r[1])


class Detector:
    def __init__(self, cfg, base_dir='.'):
        self.cfg, self.base = cfg, base_dir
        self.classes = load_classes(os.path.join(base_dir, cfg['classes_file']))
        self.nc = len(self.classes)
        self.session = None; self.error = None; self.meta = {}
        self.last_ms = None
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        path = os.path.join(self.base, self.cfg['path'])
        if not os.path.exists(path):
            self.error = f'model file not found: {self.cfg["path"]} (train + export first; see README)'
            return
        try:
            import onnxruntime as ort
            so = ort.SessionOptions(); so.intra_op_num_threads = int(self.cfg.get('threads', 4))
            so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self.session = ort.InferenceSession(path, so, providers=['CPUExecutionProvider'])
            self.inp = self.session.get_inputs()[0]
            shp = self.inp.shape
            self.imgsz = int(shp[2]) if isinstance(shp[2], int) else int(self.cfg['imgsz'])
            mp = os.path.splitext(path)[0] + '.meta.json'
            if os.path.exists(mp):
                self.meta = json.load(open(mp))
            out_nc = self.session.get_outputs()[0].shape
            if isinstance(out_nc[1], int) and out_nc[1] != 4 + self.nc and out_nc[-1] != 4 + self.nc:
                raise ValueError(f'model output {out_nc} does not match {self.nc} classes in {self.cfg["classes_file"]}')
        except Exception as e:                      # noqa: BLE001 - surfaced in the UI, never hidden
            self.session = None; self.error = f'model failed to load: {e}'

    @property
    def ready(self):
        return self.session is not None

    def predict(self, bgr):
        if not self.ready:
            raise RuntimeError(self.error)
        t0 = time.perf_counter()
        img, r, left, top = letterbox(bgr, self.imgsz)
        x = np.ascontiguousarray(img[:, :, ::-1].transpose(2, 0, 1)[None], dtype=np.float32) / 255.0
        with self._lock:
            out = self.session.run(None, {self.inp.name: x})[0]
        res = decode(out, self.nc, r, left, top, bgr.shape[:2], self.cfg['conf_floor'], self.cfg['nms_iou'])
        self.last_ms = (time.perf_counter() - t0) * 1000
        return [Detection(c, self.classes[c]['name'], cf, (x1, y1, x2, y2)) for c, cf, x1, y1, x2, y2 in res]


LEVEL_COLOR = {'HIGH': (40, 40, 220), 'LOW': (0, 165, 255), 'UNCERTAIN': (0, 215, 255), 'NO_RISK': (80, 180, 60)}


def draw(frame, dets, classes):
    import cv2
    for d in dets:
        k = classes[d.cls_id]
        col = LEVEL_COLOR.get({'HIGH': 'HIGH', 'LOW': 'LOW', 'NO': 'NO_RISK'}.get(k.get('level'), ''), (200, 160, 40))
        x1, y1, x2, y2 = map(int, d.box)
        cv2.rectangle(frame, (x1, y1), (x2, y2), col, 2)
        t = f'{d.name} {d.conf:.2f}'
        (tw, th), _ = cv2.getTextSize(t, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 1)
        cv2.rectangle(frame, (x1, max(0, y1 - th - 6)), (x1 + tw + 4, y1), col, -1)
        cv2.putText(frame, t, (x1 + 2, max(th, y1 - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
    return frame
