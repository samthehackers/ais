#!/usr/bin/env bash
# Opens the dashboard full-screen on the Pi's own display once the service is up (used by setup.sh --kiosk).
URL="${1:-http://localhost:8080}"
# single instance (autostart can fire from two places)
exec 9>/tmp/edgeguard-kiosk.lock; flock -n 9 || exit 0
for _ in $(seq 1 90); do curl -fs "$URL/health" >/dev/null 2>&1 && break; sleep 1; done
BROWSER="$(command -v chromium-browser || command -v chromium || true)"
[ -n "$BROWSER" ] || { echo "chromium not installed: sudo apt install chromium-browser"; exit 1; }
exec "$BROWSER" --kiosk --noerrdialogs --disable-infobars --no-first-run --disable-session-crashed-bubble "$URL"
