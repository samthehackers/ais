#!/usr/bin/env bash
# Builds llama.cpp on the Pi, downloads a small vision model ONCE (needs internet now), then runs it as a local service.
# After this the offline LLM works with no internet. EDGEGUARD detection never depends on it.
# Usage: scripts/install_llamacpp.sh [huggingface-repo]     default: ggml-org/SmolVLM-500M-Instruct-GGUF
set -euo pipefail
cd "$(dirname "$0")/.."; DIR="$(pwd)"; RUN_USER="${SUDO_USER:-$USER}"; MODEL="${1:-ggml-org/SmolVLM-500M-Instruct-GGUF}"
sudo apt-get update && sudo apt-get install -y build-essential cmake git libcurl4-openssl-dev curl
LL="$HOME/llama.cpp"
[ -d "$LL" ] || git clone --depth 1 https://github.com/ggml-org/llama.cpp "$LL"
( cd "$LL" && git pull --ff-only || true; cmake -B build -DLLAMA_CURL=ON && cmake --build build -j"$(nproc)" --target llama-server )
BIN="$LL/build/bin/llama-server"; [ -x "$BIN" ] || { echo "build failed"; exit 1; }
touch edgeguard.env; chmod 600 edgeguard.env
sed -i '/^LLAMA_/d' edgeguard.env
printf 'LLAMA_SERVER_BIN=%s\nLLAMA_HF_MODEL=%s\n' "$BIN" "$MODEL" >> edgeguard.env
sed -e "s|@DIR@|$DIR|g" -e "s|@USER@|$RUN_USER|g" scripts/edgeguard-llama.service | sudo tee /etc/systemd/system/edgeguard-llama.service >/dev/null
sudo systemctl daemon-reload && sudo systemctl enable --now edgeguard-llama.service
echo "Downloading/loading the model (first start needs internet; can take several minutes)..."
for _ in $(seq 1 900); do curl -fs http://127.0.0.1:8081/health >/dev/null 2>&1 && break; sleep 1; done
curl -fs http://127.0.0.1:8081/health >/dev/null || { echo "llama-server not healthy yet: check  journalctl -u edgeguard-llama -f"; exit 1; }
# pin the cached files so later boots never need the network
CACHE="${LLAMA_CACHE:-$HOME/.cache/llama.cpp}"; KEY="$(echo "$MODEL" | tr '/' '_')"
M="$(find "$CACHE" -name "${KEY}*.gguf" ! -name '*mmproj*' 2>/dev/null | head -1 || true)"; P="$(find "$CACHE" -name "${KEY}*mmproj*.gguf" 2>/dev/null | head -1 || true)"
if [ -n "$M" ] && [ -n "$P" ]; then printf 'LLAMA_MODEL_FILE=%s\nLLAMA_MMPROJ_FILE=%s\n' "$M" "$P" >> edgeguard.env; sudo systemctl restart edgeguard-llama.service; echo "Model files pinned for fully offline start."
else echo "Could not locate cached model files to pin; it will still work, and re-use the cache."; fi
echo "Offline LLM ready at http://127.0.0.1:8081 . Restart EDGEGUARD (sudo systemctl restart edgeguard) to pick it up."
