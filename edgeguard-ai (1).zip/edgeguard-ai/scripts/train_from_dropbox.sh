#!/usr/bin/env bash
# One command: drop-folder images + labels -> dataset -> train -> export ONNX -> evaluate -> plots -> deploy to models/best.onnx.
# Run on a machine with a GPU or plenty of time (Colab/PC); training on the Pi itself is impractically slow.
#   MODEL=yolov8n.pt EPOCHS=100 IMGSZ=640 scripts/train_from_dropbox.sh
set -euo pipefail
cd "$(dirname "$0")/.."
MODEL="${MODEL:-yolov8n.pt}"; EPOCHS="${EPOCHS:-100}"; IMGSZ="${IMGSZ:-640}"; NAME="$(basename "$MODEL" .pt)"
PY="${PYTHON:-python3}"; [ -f .venv/bin/python ] && PY=.venv/bin/python
$PY -c "import ultralytics" 2>/dev/null || { echo "Training needs:  pip install -r requirements-train.txt"; exit 1; }
N=$(find training_data/images -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) | wc -l)
[ "$N" -gt 0 ] || { echo "No images in training_data/images. Drop pictures there (+ labels in training_data/labels, or a Label Studio .json). See training_data/README.md"; exit 1; }
JSON=$(ls training_data/*.json 2>/dev/null | head -1 || true)
if [ -n "$JSON" ]; then SRC=(--export "$JSON" --images training_data/images); else SRC=(--yolo-dir training_data); fi
$PY dataset/prepare_dataset.py "${SRC[@]}" --out dataset/yolo --oversample-rare 60
$PY training/train.py --data dataset/yolo/data.yaml --model "$MODEL" --epochs "$EPOCHS" --imgsz "$IMGSZ" --name "$NAME"
$PY export_model.py --weights "runs/$NAME/weights/best.pt" --imgsz "$IMGSZ" --out models/best.onnx
$PY evaluate.py --model models/best.onnx --data dataset/yolo/data.yaml --split test --out evaluation/results
$PY evaluation/plot_results.py --run "runs/$NAME" --eval evaluation/results --out evaluation/plots
echo "Done. Model: models/best.onnx . Check evaluation/results/metrics.json BEFORE trusting it. Copy models/ to the Pi, then: sudo systemctl restart edgeguard"
