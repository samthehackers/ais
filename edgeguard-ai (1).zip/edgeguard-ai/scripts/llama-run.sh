#!/usr/bin/env bash
# Starts llama.cpp's llama-server for EDGEGUARD's OPTIONAL offline second opinion. Uses cached local files when known
# (fully offline), otherwise downloads once via -hf. Low priority + 2 threads so the detector keeps its CPU.
set -euo pipefail
BIN="${LLAMA_SERVER_BIN:-$HOME/llama.cpp/build/bin/llama-server}"
PORT="${LLAMA_PORT:-8081}"
[ -x "$BIN" ] || { echo "llama-server not found at $BIN (run scripts/install_llamacpp.sh)"; exit 1; }
if [ -n "${LLAMA_MODEL_FILE:-}" ] && [ -n "${LLAMA_MMPROJ_FILE:-}" ] && [ -f "$LLAMA_MODEL_FILE" ] && [ -f "$LLAMA_MMPROJ_FILE" ]; then
  exec "$BIN" -m "$LLAMA_MODEL_FILE" --mmproj "$LLAMA_MMPROJ_FILE" --host 127.0.0.1 --port "$PORT" -t 2 -c 4096 -np 1 ${LLAMA_EXTRA_ARGS:-}
fi
exec "$BIN" -hf "${LLAMA_HF_MODEL:-ggml-org/SmolVLM-500M-Instruct-GGUF}" --host 127.0.0.1 --port "$PORT" -t 2 -c 4096 -np 1 ${LLAMA_EXTRA_ARGS:-}
