#!/usr/bin/env python3
"""Export trained weights to a CPU deployment model (ONNX by default; NCNN optional) + metadata.

  python export_model.py --weights runs/yolov8n/weights/best.pt --imgsz 640 --out models/best.onnx
  python export_model.py --weights ... --int8 --calib dataset/yolo/images/val     # optional static INT8
INT8 is OFF by default: it must be re-evaluated (evaluate.py) and only used if accuracy is retained.
"""
import argparse, hashlib, json, os, platform, shutil, sys, time


def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def quantize_int8(src, dst, calib_dir, imgsz, n=100):
    import cv2, numpy as np, onnxruntime as ort
    from onnxruntime.quantization import CalibrationDataReader, QuantType, quantize_static
    from inference import letterbox
    files = [os.path.join(dp, f) for dp, _, fs in os.walk(calib_dir) for f in fs if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:n]
    if not files:
        raise SystemExit('no calibration images found')
    name = ort.InferenceSession(src, providers=['CPUExecutionProvider']).get_inputs()[0].name

    class R(CalibrationDataReader):
        def __init__(s): s.it = iter(files)
        def get_next(s):
            p = next(s.it, None)
            if p is None: return None
            im, *_ = letterbox(cv2.imread(p), imgsz)
            return {name: np.ascontiguousarray(im[:, :, ::-1].transpose(2, 0, 1)[None], dtype=np.float32) / 255.0}
    quantize_static(src, dst, R(), weight_type=QuantType.QInt8, activation_type=QuantType.QUInt8)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weights', required=True); ap.add_argument('--imgsz', type=int, default=640)
    ap.add_argument('--out', default='models/best.onnx'); ap.add_argument('--format', choices=['onnx', 'ncnn'], default='onnx')
    ap.add_argument('--int8', action='store_true'); ap.add_argument('--calib')
    a = ap.parse_args()
    from ultralytics import YOLO
    import yaml
    m = YOLO(a.weights)
    path = m.export(format=a.format, imgsz=a.imgsz, opset=12, simplify=True, dynamic=False, half=False)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    if a.format == 'onnx':
        shutil.copy2(path, a.out); final = a.out
        if a.int8:
            if not a.calib: raise SystemExit('--int8 needs --calib <image dir>')
            final = os.path.splitext(a.out)[0] + '.int8.onnx'; quantize_int8(a.out, final, a.calib, a.imgsz)
    else:
        final = path
    classes = yaml.safe_load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'configs', 'classes.yaml')))
    names_model = {int(k): v for k, v in m.names.items()}
    names_cfg = {int(k): v['name'] for k, v in classes['classes'].items()}
    if names_model != names_cfg:
        sys.exit(f'CLASS MISMATCH between weights and configs/classes.yaml:\n{names_model}\n{names_cfg}')
    meta = dict(source_weights=os.path.abspath(a.weights), exported=os.path.abspath(final), format=a.format, imgsz=a.imgsz,
                classes=names_cfg, sha256=sha256(final) if os.path.isfile(final) else None,
                size_mb=round(os.path.getsize(final) / 1e6, 2) if os.path.isfile(final) else None,
                int8=bool(a.int8), exported_at=time.strftime('%Y-%m-%dT%H:%M:%S'), python=platform.python_version(),
                note='Re-run evaluate.py on this exact file before deployment; INT8/FP32 accuracy must be compared.')
    json.dump(meta, open(os.path.splitext(final)[0] + '.meta.json', 'w'), indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == '__main__':
    main()
