"""Drop-folder image analysis. Put images in inbox/ (or upload in the dashboard); results appear in outbox/ as an
annotated .jpg and a .json. Single-image results have no temporal smoothing, so treat them as one frame's opinion."""
import json, logging, os, shutil, threading, time, uuid
import cv2
from inference import draw, LEVEL_COLOR
from risk_engine import RiskEngine

log = logging.getLogger('edgeguard.inbox')
EXT = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}


def analyze_image(detector, risk_cfg, path):
    img = cv2.imread(path)
    if img is None: raise ValueError('not a readable image')
    dets = detector.predict(img)
    st = RiskEngine(detector.classes, risk_cfg).assess_frame(dets)
    ann = draw(img.copy(), dets, detector.classes)
    col = LEVEL_COLOR.get(st.frame_level, (150, 150, 150))
    cv2.rectangle(ann, (0, 0), (ann.shape[1], 30), col, -1)
    cv2.putText(ann, f'{st.frame_level.replace("_", " ")} (single image)', (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)
    return img, ann, dets, st


class InboxWatcher(threading.Thread):
    def __init__(self, cfg, base, detector, risk_cfg, mllm):
        super().__init__(daemon=True, name='inbox')
        self.cfg, self.det, self.risk_cfg, self.mllm = cfg, detector, risk_cfg, mllm
        j = lambda p: p if os.path.isabs(p) else os.path.join(base, p)
        self.inbox, self.outbox = j(cfg.get('dir', 'inbox')), j(cfg.get('out_dir', 'outbox'))
        self.done_dir, self.fail_dir = os.path.join(self.inbox, 'processed'), os.path.join(self.inbox, 'failed')
        for d in (self.inbox, self.outbox, self.done_dir, self.fail_dir): os.makedirs(d, exist_ok=True)
        self.stop_evt = threading.Event(); self.lock = threading.Lock(); self.processed = 0; self.errors = 0; self.note = None

    def stop(self): self.stop_evt.set()

    def run(self):
        while not self.stop_evt.is_set():
            try: self.scan()
            except Exception as e: log.error('inbox scan failed: %s', e)   # noqa: BLE001
            self.stop_evt.wait(float(self.cfg.get('poll_s', 2)))

    def scan(self):
        for f in sorted(os.listdir(self.inbox)):
            p = os.path.join(self.inbox, f)
            if not os.path.isfile(p) or os.path.splitext(f)[1].lower() not in EXT or time.time() - os.path.getmtime(p) < 1.0: continue
            if not self.det.ready:
                self.note = 'model unavailable: images wait in the inbox'; return
            self.note = None; self.process(p)

    def process(self, p):
        name = os.path.basename(p); rid = f"{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
        try:
            img, ann, dets, st = analyze_image(self.det, self.risk_cfg, p)
            cv2.imwrite(os.path.join(self.outbox, rid + '.jpg'), ann, [cv2.IMWRITE_JPEG_QUALITY, 85])
            res = dict(id=rid, source=name, ts=time.strftime('%Y-%m-%dT%H:%M:%S'), single_image=True, level=st.frame_level, hazard=st.hazard,
                       detection_conf=round(st.detection_conf, 3), risk_class_conf=round(st.risk_class_conf, 3), reasons=st.reasons,
                       proximity_hint=st.proximity_hint, detections=[dict(name=d.name, conf=round(d.conf, 3), box=[round(x, 1) for x in d.box]) for d in dets],
                       mllm={'status': 'disabled'}, note='single image: no temporal smoothing; NO_RISK only means nothing was detected above threshold')
            ctx = f'{st.frame_level}, detections: ' + ', '.join(f'{d.name} {d.conf:.2f}' for d in dets[:5])
            if self.mllm and self.mllm.submit(img, ctx, lambda r, rid=rid: self._set_mllm(rid, r), kind='inbox'):
                res['mllm'] = {'status': 'pending'}
            self._write(rid, res)
            shutil.move(p, os.path.join(self.done_dir, f'{rid}_{name}')); self.processed += 1
        except Exception as e:                                              # noqa: BLE001
            self.errors += 1; log.error('failed %s: %s', name, e)
            dst = os.path.join(self.fail_dir, f'{rid}_{name}')
            try: shutil.move(p, dst); open(dst + '.error.txt', 'w').write(str(e))
            except OSError: pass

    def _write(self, rid, res):
        with self.lock:
            tmp = os.path.join(self.outbox, rid + '.json.tmp'); json.dump(res, open(tmp, 'w'), indent=1); os.replace(tmp, os.path.join(self.outbox, rid + '.json'))

    def _set_mllm(self, rid, r):
        with self.lock:
            p = os.path.join(self.outbox, rid + '.json')
            if not os.path.exists(p): return
            res = json.load(open(p)); res['mllm'] = dict(r, status='done' if r.get('ok') else 'unavailable'); tmp = p + '.tmp'
            json.dump(res, open(tmp, 'w'), indent=1); os.replace(tmp, p)

    def results(self, n=20):
        fs = sorted((f for f in os.listdir(self.outbox) if f.endswith('.json')), reverse=True)[:n]; out = []
        for f in fs:
            try: out.append(json.load(open(os.path.join(self.outbox, f))))
            except (OSError, ValueError): pass
        return out

    def status(self):
        pend = len([f for f in os.listdir(self.inbox) if os.path.splitext(f)[1].lower() in EXT])
        return dict(dir=self.inbox, waiting=pend, processed=self.processed, errors=self.errors, note=self.note)
