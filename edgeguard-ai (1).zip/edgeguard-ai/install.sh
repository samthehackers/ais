#!/usr/bin/env bash
# EDGEGUARD AI installer (Raspberry Pi OS 64-bit / Debian). Needs internet ONCE; the running system is fully offline.
set -euo pipefail
cd "$(dirname "$0")"; chmod +x scripts/*.sh ./*.sh 2>/dev/null || true
[ "$(uname -m)" = "aarch64" ] || echo "WARNING: not 64-bit ARM ($(uname -m)); continuing for development use."
if command -v apt-get >/dev/null; then
  sudo apt-get update
  sudo apt-get install -y python3-venv python3-pip alsa-utils libgl1 libglib2.0-0 \
       || { echo "apt install failed"; exit 1; }
  sudo apt-get install -y curl util-linux
  sudo apt-get install -y chromium-browser || sudo apt-get install -y chromium || echo 'chromium not installed: kiosk display will not work'
  sudo apt-get install -y python3-picamera2 || echo "picamera2 not available: CSI camera support disabled (USB cameras still work)"
fi
# --system-site-packages lets the venv see apt's picamera2 for CSI cameras
python3 -m venv --system-site-packages .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
mkdir -p logs/snapshots models inbox/processed inbox/failed outbox
python3 - <<'PY'
import cv2, flask, onnxruntime, yaml, psutil, numpy
print("dependencies OK  onnxruntime", onnxruntime.__version__, "providers", onnxruntime.get_available_providers())
PY
echo "Installed. Next: copy your exported model to models/best.onnx (+ best.meta.json), then ./setup.sh to enable boot start, or ./run.sh to run now."
