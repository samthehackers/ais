# Model research (sources checked this session; Pi 5 numbers are vendors', NOT measured on your hardware)

| Candidate | Verified facts | Status for EDGEGUARD |
|---|---|---|
| **YOLO26n -> NCNN** (Ultralytics) | Ultralytics Pi 5 guide: 67.03 ms/image (~15 FPS), 9.4 MB, mAP50-95 0.4784 on COCO128, FP32, 640 px, inference only (excludes pre/post), Ultralytics 8.4.108. NCNN was their fastest export. `model.export(format="ncnn")` -> `yolo26n_ncnn_model/`. NCNN export disables YOLO26's end-to-end head (traditional `[4+nc, 8400]` output). | **Recommended default** (needs an NCNN backend in `inference.py`: TODO) |
| **Arm Runtime for YOLO26** (HF `Arm/Arm-Runtime-for-YOLO26-on-Raspberry-Pi-5`, Apache-2.0) | Arm's own table, Pi 5, 640 px: 36.60 ms/img, mAP50-95 0.4863 vs NCNN 67.20 ms / 0.4902, ONNX Runtime 126.90 ms. Supports "standard YOLO26n and compatible fine-tuned variants" at square 320/480/640/800/960/1280. Fixed graph; needs Raspberry Pi OS **Trixie**. Convert with `make model CHECKPOINT=...pt`; Python API; picamera2 example exists. | **Benchmark candidate.** Adopt only after OUR fine-tuned 11-class checkpoint converts and matches PyTorch/NCNN detections. Not yet demonstrated. |
| **ONNX Runtime** (current backend) | ~2-3.5x slower than NCNN/Arm on Pi 5 in the sources above (126.9 ms). | Keep as dev/fallback only. |
| **Pi AI HAT+ (Hailo)** | HEF is not a direct Ultralytics export: ONNX -> Hailo DFC compile, which cannot run on ARM/Pi. **YOLO26 end-to-end exports are not supported on Hailo**; a traditional head is needed. | Optional later. Not assumed installed. |

Output formats: YOLO26 default ONNX output is end-to-end `[1,300,6]` = `x1,y1,x2,y2,conf,cls`; `end2end=False` gives the traditional `[1,4+nc,8400]` that `inference.py` decodes today. The `[1,300,6]` decoder is TODO.

Not verified this session: licence terms of Ultralytics weights (check AGPL/enterprise terms before commercial use), RAM use and temperature on a real Pi, and accuracy on your data.

Decision rule: pick the runtime by (1) custom-model compatibility proven, (2) your measured latency on a Pi 5 (`benchmark.py`), (3) accuracy on the test split via `evaluate.py`. Do not choose by the vendor tables alone.
