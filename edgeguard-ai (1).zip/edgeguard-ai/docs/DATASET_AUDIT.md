# Dataset audit (from the Label Studio export; full numbers in `dataset/audit_report.md`)

- 1,930 tasks: 1,831 valid with boxes, 12 valid empty, 87 cancelled. 1,361 unique filenames; 510 uploaded 2-4 times. **Image files were not supplied.**
- **275 filenames carry conflicting labels across uploads (144 disagree on the risk level).** Quarantined pending human review. 1,025 unique images remain.
- Boxes after dedupe: toddler-near-knife HIGH/LOW/NO 241/114/78; toddler-near-iron HIGH/LOW/NO 211/108/139; toddlers 72; adult female 38; adult male 23; electric iron 2; knife 5.

## Your proposed taxonomy vs what the data supports
| Proposed class | Boxes available | Verdict |
|---|---|---|
| toddler | 72 (only in images WITHOUT a risk label) | too few, and not co-labelled with hazards |
| adult | 61 | usable, small |
| knife | 5 | **cannot train** |
| electric_iron | 2 | **cannot train** |
| electrical_socket, hot_surface, other_hazard | 0 | **do not exist in the data** |

The compound boxes ("TODDLER NEAR KNIFE (HIGH RISK)") cover the whole scene. Object-level boxes cannot be derived from them without new human annotation; generating them would be fabricating ground truth. So the spec's "detect objects, then reason spatially" approach cannot be trained from this data yet.

**Decision:** keep the compound labels as scene-level risk evidence (approach A, as built). To reach the spec's object-level design, annotate separate `toddler`, `adult`, `knife`, `electric_iron` boxes on the 1,025 unique images (Label Studio pre-labelling can speed this up), after which the tracker + spatial risk engine can use them.
